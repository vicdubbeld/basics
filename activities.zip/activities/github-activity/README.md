# Assignment:
Using GitHub and the Command Line:

* Create a new public GitHub repository and name it `wk1-homework`. Be sure to check the box for “initialize this repository with a README.” 
* Next, clone the repo inside your local directory `code\homework` directory
* Then create an HTML file inside the local directory named `index.html`
* `Add`, `Commit`, and `Push` the code to GitHub.
___
## Bonus:
* Find a partner in class, and fork their repository to your own GitHub account. `Clone` this forked repository to your local directory.
* `Add`, `Commit`, and `Push` the code back to your forked copy. 
* Finally, submit a pull request to send your changes to your partner’s repo.